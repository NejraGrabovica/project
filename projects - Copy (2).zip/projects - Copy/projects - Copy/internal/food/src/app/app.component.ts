import { Component, OnInit } from '@angular/core';

import {AppMaterialModule} from './app-material/app-material.module';

import * as PDFJS from "pdfjs-dist/webpack.js";
import { PDFPageProxy, PDFPageViewport, PDFRenderTask } from 'pdfjs-dist';

import {AppService} from './app.service';

//import { saveAs } from 'file-saver';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.scss']
})
export class AppComponent implements OnInit {
  
  title = 'food';
  bghmLink = '';
  bghm = [];
  rp = [];
  rpLink = '';
  neg = [];
  negLink = 'http://naherholungsgebiet-vaihingen.de/mittagskarte/Wochenkarte.pdf';
  
  displayedColumns: string[] = ['day', 'menu1', 'menu2'];
  displayedColumnsRP: string[] = ['day', 'menu1', 'menuK', 'menu2', 'menu3', 'menu4'];
  displayedColumnsNEG: string[] = ['day', 'menu1', 'menu2', 'menu3'];
  todayDay = 'MO';
  filtered = true;

  
  constructor(private appService: AppService) {
    
    
  }
  
  ngOnInit(): void {
    let days = ['SO', 'MO', 'DI', 'MI', 'DO', 'FR', 'SA'];
    this.todayDay = days[(new Date()).getDay()];
    
    if(this.todayDay[0] == 'S')
      this.filtered = false;
    
    this.extractDishesLink()
  }
  
  async getPDFFileWithCORS(path) {
    return new Promise((url) => {
      this.appService.getPDF(path).subscribe((res) => {
        var file = new Blob([res], { type: 'application/pdf' }); 
        var fileURL = URL.createObjectURL(file);
        url(fileURL);
      });
    });
  }
  
  getRPFiltered() {
    return this.rp.filter(elem => {return elem.day == this.todayDay || !this.filtered;});
  }
  
  getBGHMFiltered() {
    return this.bghm.filter(elem => {return elem.day == this.todayDay || !this.filtered;});
  }
  
  getNEGFiltered() {
    return this.neg.filter(elem => {return elem.day == this.todayDay || !this.filtered;});
  }
  
  extractDishesLink() {
    this.rp = [];
    this.rpLink = '';
    this.bghm = [];
    this.bghmLink = '';
    this.neg = [];
    
    this.appService.getPage("https://www.gourmet-compagnie.de/betriebsgastronomie/wochenkarte.html")
    .subscribe(res => {
        //<a href="/files/speiseplan_regierungspraesidium_kw_05_1.pdf" target="_blank" class="pdflink">Regierungspräsidium KW 05</a>
        let match = /speiseplan_regierungspraesidium(.*?).pdf/.exec(res)[0];
        this.rpLink = 'https://www.gourmet-compagnie.de/files/' + match;
        this.getRP(this.rpLink);
    });
    
    this.appService.getPage("http://www.rolandsmaultaschen.de/kantine.html")
    .subscribe(res => {
        //href="mediapool/90/907433/data/Speiseplan_BGHM_Kantine_07.01.-18.01.2019.pdf"
        // extract both links
        let match = res.match(/mediapool\/(.*?)\/data\/Speiseplan_BGHM_Kantine(.*?).pdf/g);
        
        // extract end date of links
        let extrDate1 = (/-(.*).pdf/.exec(match[0])[1]).split('.');
        let extrDate2 = (/-(.*).pdf/.exec(match[1])[1]).split('.');
        
        // if today is before 1st date -> 1st link, otherwise -> 2nd link
        if(this.checkDate(extrDate1[2], extrDate1[1], extrDate1[0])) {
          this.bghmLink = 'http://www.rolandsmaultaschen.de/' + match[0];
          this.getBGHM(this.bghmLink, extrDate1);
        } else {
          this.bghmLink = 'http://www.rolandsmaultaschen.de/' + match[1];
          this.getBGHM(this.bghmLink, extrDate2);
        }
    });
    
    this.getNEG(this.negLink);
  }
  
  // returns true if today is before date(y, m, d)
  checkDate(y, m, d) {
    
    // month-1 as january is 0. 
    // 17:00? ...well they close at 14:30
    var date = new Date(y, m-1, d, 17); 
    var today = new Date();
    
    return today < date;
  }
  
  
  getBGHM(path, endDate) {
    this.getPDFFileWithCORS(path).then(url => {
      this.getBGHMText(url, endDate);
    });
  }
  
  getRP(path) {
    this.getPDFFileWithCORS(path).then(url => {
      this.getRPText(url);
    });
  }
  
  getNEG(path) {
    this.getPDFFileWithCORS(path).then(url => {
      this.getNEGText(url);
    });
  }
  
  getBGHMText(pdfUrl, endDate) {    
  
    let that = this;
    // waiting on gettext to finish completion, or error
    this.gettext(pdfUrl, 1).then(function (text) {
      
      let dateMatch = text.match(/(?:Vom (?:.*?)- )(..\...\.....)/gm);
      dateMatch = dateMatch[0].match(/- (..\...\.....)/);
      
      endDate = dateMatch[1].split('.');
      let first = false;
      if(that.checkDate(endDate[2], endDate[1], endDate[0])) {
        first = true;
      }
      
      let dayMatch = text.match(/(Montag|Dienstag|Mittwoch|Donnerstag|Freitag)(.*?)\((([a-n]|([1]?[1-9]))([1-4](\|?))*(, )?)*\)(.*?)\((([a-n]|([1]?[1-9]))([1-4](\|?))*(, )?)*\)/gm);
      
      let len = dayMatch.length;
      for (let i = (first ? 0 : len/2); i < (first ? len/2 : len); i++) {
        let temp = {};
        let match = dayMatch[i].match(/(Montag|Dienstag|Mittwoch|Donnerstag|Freitag)(.*?)(\((([a-n]|([1]?[1-9]))([1-4](\|?))*(, )?)*\))/);
        temp['day'] = (match[1][0]+match[1][1]).toUpperCase(); // Montag -> MO (consistency)
        temp['menu1'] = match[2]/* + match[3]*/; // Zusatzstoffe
        match = dayMatch[i].match(/(?:\((?:(?:[a-n]|(?:[1]?[1-9]))(?:[1-4](?:\|?))*(?:, )?)*\))(.*?)(\((([a-n]|([1]?[1-9]))([1-4](\|?))*(, )?)*\))/);
        temp['menu2'] = match[1]/* + match[2]*/; // Zusatzstoffe
        that.bghm.push(temp);
      }
    }, function (reason) {
      console.error(reason);
    });
  }
  
  getRPText(pdfUrl) {    
    let that = this;
    // waiting on gettext to finish completion, or error
    this.gettext(pdfUrl, 2).then(function (text) {
      // remove unnecessary content
      let globalMatch = /Menü IV(.*)Zusatzstoffe/.exec(text)[0];
      let dayMatch = globalMatch.match(/(MO|DI|MI|DO|FR)(.*?)Zusatzstoffe/g);
      
      for (let elem of dayMatch) {
        let temp = {};
        let match = elem.match(/(MO|DI|MI|DO|FR|START)(.*?)(END|Zusatzstoffe)/g);
        temp['day'] = match[0][0]+match[0][1];
        
        let reg = /(?:MO|DI|MI|DO|FR|START)(.*?)(?:END|Zusatzstoffe)/;
        temp['menu1'] = reg.exec(match[0])[1];
        temp['menuK'] = reg.exec(match[1])[1];
        temp['menu2'] = reg.exec(match[2])[1];
        temp['menu3'] = reg.exec(match[3])[1];
        temp['menu4'] = reg.exec(match[4])[1];

        that.rp.push(temp);
      }

    }, function (reason) {
      console.error(reason);
    });
  }
  
  getNEGText(pdfUrl) {    
    let that = this;
    // waiting on gettext to finish completion, or error
    this.gettext(pdfUrl, 3).then(function (text) {
      // remove unnecessary content
      let globalMatch = text.match(/(Montag|Dienstag|Mittwoch|Donnerstag|Freitag) ?END_START(.*?)END_START(.*?)END_START(.*?)END/gm);
      
      for (let elem of globalMatch) {
        let temp = {};
        let match = elem.match(/(Montag|Dienstag|Mittwoch|Donnerstag|Freitag|START)(.*?)(END)/g);
        temp['day'] = (match[0][0]+match[0][1]).toUpperCase();
        
        let reg = /(?:Montag|Dienstag|Mittwoch|Donnerstag|Freitag|START)(.*?)(?:END)/;
        temp['menu1'] = reg.exec(match[1])[1];
        temp['menu2'] = reg.exec(match[2])[1];
        temp['menu3'] = reg.exec(match[3])[1];

        that.neg.push(temp);
      }
    }, function (reason) {
      console.error(reason);
    });
  }
  
  gettext(pdfUrl, opt){
    //var pdf = PDFJS.getDocument(pdfUrl);
    var pdf = PDFJS.getDocument(pdfUrl);
    return pdf.then(function(pdf) { // get all pages text
         var maxPages = pdf._pdfInfo.numPages;
         var countPromises = []; // collecting all page promises
         for (var j = 1; j <= maxPages; j++) {
            var page = pdf.getPage(j);

            var txt = "";
            countPromises.push(page.then(function(page) { // add page promise
                var textContent = page.getTextContent();
                return textContent.then(function(text){ // return content promise

                  if(opt == 1) {
                    
                    return text.items.map(function (s) {  return s.str }).join(''); // value page text 
                    
                  } else if(opt == 2) {
                    
                    var last = 1000;
                    return text.items.map(function (s) { 
                      /*console.log(s.transform[4] + ', ' + s.transform[5] + ' ' + s.str);*/
                      let end = s.transform[5] - last > 5; 
                      last = s.transform[5]; 
                      return (end ? 'END_START' : '') + s.str // marker
                    }).join(''); // value page text 
                    
                  } else {
                    
                    var last = 1000;
                    return text.items.map(function (s) { 
                      /*console.log(s.transform[4] + ', ' + s.transform[5] + ' ' + s.str);*/
                      let end = s.transform[5] != last; 
                      last = s.transform[5]; 
                      return (end ? 'END_START' : '') + s.str // marker
                    }).join(''); // value page text 
                    
                  }

                });
            }));
         }
         // Wait for all pages and join text
         return Promise.all(countPromises).then(function (texts) {
           
           return texts.join('');
         });
    });
  }
    
}