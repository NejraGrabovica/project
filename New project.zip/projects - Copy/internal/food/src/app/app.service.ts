import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders } from '@angular/common/http';

@Injectable()
export class AppService {
  constructor(private http: HttpClient) { }
  
  getPDF(path): any {
    return this.http.get('https://cors-anywhere.herokuapp.com/' + path, { responseType: 'blob' as 'json' });
  }
  
  getPage(path): any { // text/html
    return this.http.get('https://cors-anywhere.herokuapp.com/' + path, { responseType: 'text' as 'json' });
  }

  private getHeaders(): HttpHeaders {
    let headers = new HttpHeaders();
    headers = headers.append('Content-Type', 'application/pdf');

    return headers;
  }
  
}