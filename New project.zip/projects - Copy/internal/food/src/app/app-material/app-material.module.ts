import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import {MatButtonModule, MatCheckboxModule, MatCardModule} from '@angular/material';
import {MatTableModule} from '@angular/material/table';
import { HeaderComponent } from './header/header.component';

@NgModule({
  declarations: [HeaderComponent],
  imports: [
    CommonModule,
    MatButtonModule, 
    MatCheckboxModule,
    MatTableModule,
    MatCardModule
  ],
  exports: [
    MatButtonModule, 
    MatCheckboxModule,
    MatTableModule,
    MatCardModule
  ],
})
export class AppMaterialModule { }
